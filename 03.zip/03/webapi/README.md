# Instrucciones

## Instalar dependencias

```bash
sudo apt update
sudo apt install python3-pip
pip3 install -r requirements.txt
```

## Correr un servidor web y el API

```bash
python3 -m http.server &
python3 microservice.py
```

Ambos comandos deben ser ejecutados desde esta misma carpeta


## Otras instrucciones

Cambiar el IP al de la maquina
